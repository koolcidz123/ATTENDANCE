import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AppHeader from '../components/AppHeader'

export default class SummaryScreen extends React.Component {
  render() {
    return (
      
      <View>
             <AppHeader/>
        <Text
          style={styles.text}>
          Summary
        </Text>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  text:{  
    fontSize: 22,
    fontWeight: 'bold',
  
   }
})
