import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet,Button } from 'react-native';
import { createAppContainer, createSwitchNavigator } from 'react-navigation';
import AppHeader from '../components/AppHeader';
import SummaryScreen from './SummaryScreen';
import db from '../config';

export default class HomeScreen extends React.Component {
   goToSummaryScreen = () => {
    this.props.navigation.navigate('SummaryScreen');
  };
  constructor() {
    super();
    this.state = {
    attendance:"",
    list:[]
    };
  }
  presentPressed =()=>{
  var present = db.ref('students/')
 present.update({
   presentPressed:this.state.attendance
 });
 if(present===true){
   this.setState({list:this.state.list.push(present)})
 }
  }

absentPressed =()=>{
  var absent = db.ref('students/')
  absent.update({
    absentPressed:this.state.attendance
  });
   this.setState({
   attendance: false
 });
}
 

  render() {
    return (
    
      <View>
       <AppHeader/>
        <View style={{ marginLeft: 30, paddingBottom: 60 }}>
          <Text style={{ fontSize: 20, marginTop: 30 }}>1.Slappy </Text>
          <Text style={{ fontSize: 20, marginTop: 30 }}>2.Goblet</Text>
        </View>
        <View>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'green' }]}
             onPress={this.presentPressed}
            
            >
            <Text style={styles.buttonText}>Present</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'green' }]}
            onPress={this.presentPressed}
           >
            <Text style={styles.buttonText}>Present</Text>
          </TouchableOpacity>
        </View>
        <View style={{ marginLeft: 210 }}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'red' }]}
            onPress={this.absentPressed}
           >
            <Text style={styles.buttonText}>Absent</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: 'red' }]}
             onPress={this.absentPressed}
           >
            <Text style={styles.buttonText}>Absent</Text>
          </TouchableOpacity>
        </View>
        <View>
         <Button title  = "Submit" 
          onPress={() => {
            this.goToSummaryScreen();
          }}
         />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  button: {
    justifyContent: 'center',
    alignSelf: 'center',
    borderWidth: 2,
    borderRadius: 15,
    marginTop: -100,
    width: 100,
    height: 40,
  },
  buttonText: {
    textAlign: 'center',
    color: 'white',
  },
});
