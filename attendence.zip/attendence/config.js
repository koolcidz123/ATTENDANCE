import firebase from "firebase";
// Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyDJBoYmPEC_i23fXjshHzHlIV7g-_efg_I",
    authDomain: "school-attendence-app-5da4c.firebaseapp.com",
    databaseURL: "https://school-attendence-app-5da4c-default-rtdb.firebaseio.com",
    projectId: "school-attendence-app-5da4c",
    storageBucket: "school-attendence-app-5da4c.appspot.com",
    messagingSenderId: "596757048373",
    appId: "1:596757048373:web:51c2ead05e32b1b60dd57c",
    measurementId: "G-DSTP37637Q"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

export default  firebase.database()